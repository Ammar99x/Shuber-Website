<?php session_start(); ?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link rel='stylesheet' href='css/style.css'>
    <title>SHUber</title>
</head>
<body>
    <div class='menu'>
        <div class='menu_holder'>
            <h2><a href='#'>SHUber</a></h2>
            <ul>
                <?php
                    if((isset($_SESSION['username']) && ($_SESSION['username']=='admin'))){
                        echo"<li><a href='admin_panel.php'>Admin panel</a></li>";
                    }
                ?>
                <li><a href='#get_a_ride'>Get a Ride</a></li>
                <li><a href='#reviews'>Reviews</a></li>
                <?php if(isset($_SESSION['id'])){echo"<li><a id='logtrigger' href='php/logout.php'>Log out</a></li>";}else{echo"<li><a id='logtrigger'>Login / Register</a></li>";} ?>
            </ul>
        </div>
    </div>
    <header>
        <div class='quick_info'>
            <div class='info_boxes'>
                <div class='box'><span><span>TELL US</span><br>where you are</span></div>
                <div class='box'><span><span>THEN WE</span><br>pick you up</span></div>
                <div class='box'><span><span>YOU GO</span><br>wherever you want</span></div>
            </div>
        </div>
    </header>
    <main>
         <div class='about_us'>
            <h3 style="color:yellow ">"Shuber is not just a taxi platform Shuber is a life style"</h3>
                <h4> Our goal is to make your life easier and modren so you can have the peace of mind you deserve.</h4>
            </div>
            <div id='get_a_ride'>
                <div class='ride_holder'>
                    <div class='form'>
                        <h2>Get a <span>Ride</span></h2>
                        <form action='' method='GET'>
                            <div class='inp'><label for='from'>From</label><input type='text' name='from' onKeyPress='mapUpdate()' id='from'></div>
                            <div class='inp'><label for='to'>To</label><input type='text' name='to' id='to'></div>
                            <div class='rad'>
                                <div><input type='radio' name='payment' id='pp' value='paypal'><label for='pp'>PayPal</label></div>
                                <div><input type='radio' name='payment' id='card' value='card'><label for='card'>Card</label></div>
                            </div>
                            <input type="hidden" name='mapFrom' id='mapFrom' value=''>
                            <?php
                                if(!(isset($_SESSION['username']))){
                                    echo"<button type='submit' style='pointer-events:none;' id='button'>Log in first</button>";
                                } else{
                                    echo"<button type='submit' name='submitRide' id='button'>Submit</button>";
                                }
                            ?>
                        </form>
                        <?php
                            if(isset($_GET['submitRide'])){
                                $from = $_GET['from'];
                                $to = $_GET['to'];
                                $payment = $_GET['payment'];
                                $map = $_GET['mapFrom'];
                                require 'php/dtb.php';
                                $insride = "INSERT INTO rides (username, frompos, topos, payment, map, status) VALUES ('{$_SESSION['username']}','$from','$to','$payment','$map','Pending..')";
                                $ridequery = mysqli_query($connection, $insride);
                                echo"<script>window.location.href='index.php#get_a_ride'</script>";
                            }
                        ?>
                    </div>
                    <div class='map'>
                        <iframe id='gmap_canvas' src='https://maps.google.com/maps?q=&amp;t=&amp;z=13&amp;ie=UTF8&amp;iwloc=&amp;output=embed' frameborder='0' scrolling='no' marginheight='0' marginwidth='0'></iframe>
                    </div>
                </div>
            </div>
        <div class='tr'></div>
            <div id='reviews'>
                <div class='reviews_holder'>
                    <h3>Tell Others</h3>
                    <p>leave a review</p>
                    <form action='' method='GET'>
                        <h4>How satisfied were you with our service?</h4>
                        <div>
                            <div><input type='radio' name='p' id='1' value='Very Unsatisfied'><label for='1'>Very Unsatisfied</label></div>
                            <div><input type='radio' name='p' id='2' value='Unsatisfied'><label for='2'>Unsatisfied</label></div>
                            <div><input type='radio' name='p' id='3' value='Ok' checked><label for='3'>Ok</label></div>
                            <div><input type='radio' name='p' id='4' value='Great'><label for='4'>Great</label></div>
                            <div><input type='radio' name='p' id='5' value='Excellent!'><label for='5'>Excellent!</label></div>
                        </div>
                        <div>
                            <textarea name='message' id='msg' cols='30' rows='10' placeholder='What was your expierence with us?'></textarea>
                        </div>
                        <?php
                            if(!(isset($_SESSION['username']))){
                                echo"<button name='submitReview' style='pointer-events:none;'>Log in first</button>";
                            } else{
                                echo"<button name='submitReview'>Submit Review</button>";
                            }
                        ?>
                    </form>
                </div>
            </div>
            <?php
                if(isset($_GET['submitReview'])){
                    $name = $_SESSION['username'];
                    $grade = $_GET['p'];
                    $msg = $_GET['message'];

                    require 'php/dtb.php';
                    $rev = "INSERT INTO reviews (username, grade, review, answer) VALUES ('$name', '$grade', '$msg', 'null')";
                    $sqlrev = mysqli_query($connection, $rev);
                    echo"<script>window.location.href='index.php#reviews';</script>";
                }
            ?>
            <div class='last_reviews'>
                    <h3>What <span>Others</span> Say</h3>
                    <div class="rev_box">
                        <?php
                            require 'php/dtb.php';
                            $getrev = "SELECT * FROM reviews ORDER BY id DESC LIMIT 3";
                            $revquery = mysqli_query($connection, $getrev);
                            while($revi = mysqli_fetch_assoc($revquery)){
                                echo"
                                <div class='box'>
                                    <p class='name'>{$revi['username']}</p>
                                <div class='text'>
                                    <p><span>{$revi['grade']} -</span> {$revi['review']}</p>
                                </div>";
                                if(!(($revi['answer'])==('null'))){
                                    echo"
                                    <div class='answer'>
                                        <h4><span>SHuber says</span></h4>
                                        <p>{$revi['answer']}</p>
                                    </div>
                                    ";
                                }
                                echo"</div>";
                            }
                        ?>
                    </div>
                </div>
            <div class='download'>
                <div class='download_holder'>
                    <h2>Download our <span>App</span></h2>
                    <h3>and <span>we</span> got your back</h3>
                    <div class='links'>
                        <a href='https://play.google.com' target='_blank'><img src='img/gp.png' alt='Google Play'></a>
                        <a href='https://www.apple.com/app-store/' target='_blank'><img src='img/as.png' alt='App Store'></a>
                    </div>
                </div>
            </div>
    </main>
    <footer>
        <div class='footer_holder'>
            <p>&copy; 2021 SHUber</p>
        </div>
    </footer>
    <div class='login'>
        <div class='log_holder'>
            <button id='closelog'>&times;</button>
            <form action='php/login.php' method='POST'>
                <div><input type='text' name='username' placeholder='Username..' required></div>
                <div><input type='password' name='pwd' placeholder='Password..' required></div>
                <div><button type='submit' name='loginBtn'>Log in</button></div>
            </form>
            <p>Don't have an account? <a href='register.php'>Register here!</a></p>
        </div>
    </div>
    <script>
        document.getElementById('logtrigger').addEventListener('click', function(){
            document.querySelector('.login').classList.toggle('active');
        })
        document.getElementById('closelog').addEventListener('click', function(){
            document.querySelector('.login').classList.remove('active');
        })
        document.addEventListener('scroll', function(){
            if(window.pageYOffset > 80){
                document.querySelector('.menu').classList.add('active');
            } else{
                document.querySelector('.menu').classList.remove('active');
            }
        })
        function mapUpdate(){
            setTimeout(function(){
                var val = document.getElementById('from').value;
                document.getElementById('gmap_canvas').setAttribute('src', 'https://maps.google.com/maps?q='+val+'&t=&z=13&ie=UTF8&iwloc=&output=embed');
                document.getElementById('mapFrom').setAttribute('value', 'https://maps.google.com/maps?q='+val+'&t=&z=13&ie=UTF8&iwloc=&output=embed');
            }, 100)
        }
    </script>
</body>
</html>