<?php session_start();
    if((isset($_SESSION['role']) && isset($_SESSION['role'])=='admin')){
        echo"<!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta http-equiv='X-UA-Compatible' content='IE=edge'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Admin Panel</title>
            <link rel='stylesheet' href='css/admin.css'>
        </head>
        <body>
            <main>
                <a href='index.php'><span><</span>Back to main page..</a>
                <div class='content_holder'><div class='rides'><h3>Rides</h3>";
                    require 'php/dtb.php';
                    $getrides = "SELECT * FROM rides WHERE status='Pending..'";
                    $sqlrides = mysqli_query($connection, $getrides);
                    while($ride = mysqli_fetch_assoc($sqlrides)){
                        echo"
                            <div class='box'>
                                <p class='name'><span>Username:</span> {$ride['username']}</p>
                                <p><span>From:</span> {$ride['frompos']}</p>
                                <p><span>To:</span> {$ride['topos']}</p>
                                <iframe id='gmap_canvas' width='450' height='450' src='{$ride['map']}' frameborder='0' scrolling='no' marginheight='0' marginwidth='0'></iframe>
                                <p><span>Payment:</span> {$ride['payment']}</p>
                                <form method='POST'>
                                    <input type='hidden' name='id' value='{$ride['id']}'>
                                    <div><button name='accRide'>ACCEPT</button><button name='rejRide'>REJECT</button></div>
                                </form>
                            </div>
                        ";
                    }

                    if(isset($_POST['accRide'])){
                        require 'php/dtb.php';
                        $upd = "UPDATE rides SET status='Accepted' WHERE id='{$_POST['id']}'";
                        mysqli_query($connection, $upd);
                        echo"<script>window.location.href='admin_panel.php';</script>";
                    }
                    if(isset($_POST['rejRide'])){
                        require 'php/dtb.php';
                        $upd = "UPDATE rides SET status='Rejected' WHERE id='{$_POST['id']}'";
                        mysqli_query($connection, $upd);
                        echo"<script>window.location.href='admin_panel.php';</script>";
                    }
                echo"</div>
                <div class='reviews'><h3>Reviews</h3>";
                    require 'php/dtb.php';
                    $getrev = "SELECT * FROM reviews WHERE answer='null'";
                    $sqlrev = mysqli_query($connection, $getrev);
                    while($rev = mysqli_fetch_assoc($sqlrev)){
                        echo"
                            <div class='box'>
                                <p class='name'><span>Username:</span> {$rev['username']}</p>
                                <p><span>Rating:</span> {$rev['grade']}</p>
                                <p><span>Message:</span> {$rev['review']}</p>
                                <form method='POST'>
                                    <input type='hidden' name='id' value='{$rev['id']}'>
                                    <textarea name='answer'></textarea>
                                    <div><button type='submit' name='submitAns'>Submit answer</button></div>
                                </form>
                            </div>
                        ";
                    }
                    if(isset($_POST['submitAns'])){
                        require 'php/dtb.php';
                        $upd = "UPDATE reviews SET answer='{$_POST['answer']}' WHERE id='{$_POST['id']}'";
                        mysqli_query($connection, $upd);
                        echo"<script>window.location.href='admin_panel.php';</script>";
                    }
                echo"</div>
                </div>
            </main>
        </body>
        </html>";
    }
?>