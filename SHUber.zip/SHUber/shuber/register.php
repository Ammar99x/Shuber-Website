<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Register | SHUber</title>
    <link rel='stylesheet' href='css/reg.css'>
</head>
<body>
    <div class='form'>
        <form action='php/register.php' method='POST'>
            <h2>Registration</h2>
            <div><input type='text' name='name' placeholder='Username..' required></div>
            <div><input type='text' name='email' placeholder='E-mail address..' required></div>
            <div><input type='password' name='pwd' placeholder='Password..' required></div>
            <div><input type='password' name='pwd-check' placeholder='Password again..' required></div>
            <div><button type='submit' name='registerAcc'>Register</button></div>
        </form>
    </div>
    <?php if((isset($_GET['regstat'])) && ($_GET['regstat']=='accountRegistered')){ echo"<script>setTimeout(function(){ window.location.href = 'index.php' }, 2000)</script>"; } ?>
</body>
</html>