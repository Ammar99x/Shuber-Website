<?php
if(isset($_POST['loginBtn'])){
    require "dtb.php";
    $username = $_POST['username'];
    $pwd = $_POST['pwd'];
    if(empty($username) || empty($pwd)){
        header("Location: ../index.php?error=emptyFields");
        exit();
    }
    else{
        $sql = "SELECT * FROM accounts WHERE username = '$username'";
        $result = mysqli_query($connection, $sql);
        if ($userData = mysqli_fetch_assoc($result)){
            $passCheck = password_verify($pwd, $userData['pass']);
            if($passCheck == false){
                header("Location: ../index.php?error=wrongPassword");
                exit();
            } else if($passCheck == true){
                session_start();
                $_SESSION['id'] = $userData['id'];
                $_SESSION['role'] = $userData['role'];
                $_SESSION['username'] = $userData['username'];
                $_SESSION['email'] = $userData['email'];
                header("Location: ../index.php?login=success");
                exit();
            } else{
                header("Location: ../index.php?error=credentialsNotCorrect");
                exit();
            }
        }
    }
} else{
    header("Location: ../index.php");
    exit();
}