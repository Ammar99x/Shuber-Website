<?php
$servername = "localhost";
$username = "root";
$pass = "";
$dBname = "shuber";

$connection = mysqli_connect($servername, $username, $pass, $dBname);

if(!$connection){
    die("Connection failed.".mysqli_connect_error());
}