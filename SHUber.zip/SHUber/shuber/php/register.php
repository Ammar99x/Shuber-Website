<?php
if(isset($_POST['registerAcc'])){
    require 'dtb.php';
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $pwdch = $_POST['pwd-check'];
    if(!($pwd == $pwdch)){
        header("Location: ../register.php?regstat=passwordNotMatch");
        exit();
    } else{
        $encryptedPassword = password_hash($pwd, PASSWORD_DEFAULT);
        $insertNewAcc = "INSERT INTO accounts (role, username, email, pass) VALUES ('user', '$name', '$email', '$encryptedPassword')";
        $res = mysqli_query($connection, $insertNewAcc);
        header("Location: ../register.php?regstat=accountRegistered");
        exit();
    }
}
?>