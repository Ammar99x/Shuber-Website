-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hostiteľ: 127.0.0.1
-- Čas generovania: Št 18.Nov 2021, 19:38
-- Verzia serveru: 10.4.11-MariaDB
-- Verzia PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáza: `shuber`
--

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `accounts`
--

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL,
  `role` tinytext DEFAULT NULL,
  `username` tinytext DEFAULT NULL,
  `email` longtext DEFAULT NULL,
  `pass` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Sťahujem dáta pre tabuľku `accounts`
--

INSERT INTO `accounts` (`id`, `role`, `username`, `email`, `pass`) VALUES
(2, 'admin', 'admin', 'admin@shuber.com', '$2y$10$ETAg6v1baLffSYv10VxQv.LfTHrQG1/YklrOQwI2FI2o9rJCYK.Zq');

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `username` tinytext DEFAULT NULL,
  `grade` tinytext DEFAULT NULL,
  `review` longtext DEFAULT NULL,
  `answer` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Sťahujem dáta pre tabuľku `reviews`
--

INSERT INTO `reviews` (`id`, `username`, `grade`, `review`, `answer`) VALUES
(1, 'John', 'Excellent!', 'My driver was very friendly!', 'null'),
(2, 'Jessica', 'Great', 'Driver was fast and friendly.', 'null'),
(3, 'Peter', 'Very Unsatisfied', 'I was late for my meeting! Driver was late and rude!', 'We are sorry!');

-- --------------------------------------------------------

--
-- Štruktúra tabuľky pre tabuľku `rides`
--

CREATE TABLE `rides` (
  `id` int(11) NOT NULL,
  `username` tinytext DEFAULT NULL,
  `frompos` tinytext DEFAULT NULL,
  `topos` longtext DEFAULT NULL,
  `payment` longtext DEFAULT NULL,
  `map` longtext DEFAULT NULL,
  `status` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Kľúče pre exportované tabuľky
--

--
-- Indexy pre tabuľku `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pre tabuľku `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pre tabuľku `rides`
--
ALTER TABLE `rides`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pre exportované tabuľky
--

--
-- AUTO_INCREMENT pre tabuľku `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pre tabuľku `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pre tabuľku `rides`
--
ALTER TABLE `rides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
